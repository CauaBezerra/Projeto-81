import React, { Component } from "react";

export default class Feed extends Component {

}